/**
 * \file wireframe.c
 *
 * \brief Implementação do arquivo principal de renderização do modelo 3D.
 *
 * \author
 * Petrucio Ricardo Tavares de Medeiros \n
 * Universidade Federal Rural do Semi-Árido \n
 * Departamento de Engenharias e Tecnologia \n
 * petrucio at ufersa (dot) edu (dot) br
 *
 * \version 1.0
 * \date May 2025
 */

#include "image.h"
#include "model.h"

int main() {
    Vertex vertices[MAX_VERTICES];
    Face faces[MAX_FACES];
    int vcount, fcount;

    clr();

    // Lê o arquivo OBJ enviado
    if (!load_obj("wolf.obj", vertices, &vcount, faces, &fcount)) {
        return 1;
    }

    Camera cam = {
        .position = {1, 3, 5},
        .target = {0, 0, 0},
        .up = {0, 1, 0}
    };

    apply_camera(vertices, vcount, cam);

    // Renderiza as faces no framebuffer
    render_faces(vertices, faces, vcount, fcount);

    Vertex p1 = {300, 100, 0};
    Vertex p2 = {400, 200, 0};
    Vertex t1 = {500, 0, 0};
    Vertex t2 = {0, -200, 0};
    
    for (float t = 0.0; t <= 1.0; t += 0.001) {
        Vertex hermite = hermit(p1, p2, t1, t2, t);
        draw_point((int)((hermite.x + 1.0f) * WIDTH / 2.0f),
                   (int)((1.0f - hermite.y) * HEIGHT / 2.0f));
    }
    
    save();
    
    return 0;
}
