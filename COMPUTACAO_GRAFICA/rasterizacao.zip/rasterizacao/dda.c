#include <stdio.h>
#include <stdlib.h>

#define width 200
#define height 200

// Definir a imagem com os três canais de cores
unsigned char image[width][height][3];

// coloca um pixel na imagem
void px(int x, int y, unsigned char r, unsigned char g, unsigned char b)
{

    // Verifica se as coordenadas estão dentro dos limites da imagem
    // e se os valores de cor estão dentro do intervalo válido (0-255)
    if (x >= 0 && x < width && y >= 0 && y < height)
    {

        image[x][y][0] = r; // Canal vermelho
        image[x][y][1] = g; // Canal verde
        image[x][y][2] = b; // Canal azul
    }
}

// Limpa a imagem.
void clearImage()
{
    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            px(x, y, 255, 255, 255); // Preenche com branco
        }
    }
}

// Função par salvar a imagem
void saveImage()
{
    // Header
    // p3/
    // width height
    // color value 255(unsigned char)
    // Pixels
    // r  g   b
    printf("P3\n%d %d\n255\n", width, height);
    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            for (int c = 0; c < 3; c++)
            {
                printf("%d \t", image[x][y][c]);
            }
            printf("\n");
        }
    }
}

// Função para desenhar uma linha usando o algoritmo DDA
void drawDDA(int x0, int y0, int x1, int y1)
{

    // Variacao nos eixos x e y
    int dx = x1 - x0;
    int dy = y1 - y0;

    // Encontrando o passo
    int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

    float x_inc = (float)dx / steps;
    float y_inc = (float)dy / steps;

    float x = x0;
    float y = y0;

    for (int i = 0; i <= steps; i++)
    {
        px(x, y, 255, 0, 0);
        x += x_inc;
        y += y_inc;
    }
}

int main()
{
    // Limpa a imagem
    clearImage();

    // Desenha uma linha usando o algoritmo DDA
    drawDDA(0, 0, 200, 200);

    // Salva a imagem
    saveImage();

    return 0;
}